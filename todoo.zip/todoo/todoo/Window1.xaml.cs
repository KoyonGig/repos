﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace todoo
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }



        private void Reg_Click(object sender, RoutedEventArgs e)
        {


        }

        static bool IsValidEmail(string email)
        {

            string pattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            return Regex.IsMatch(email, pattern);

        }

        private void Reg_Click_1(object sender, RoutedEventArgs e)
        {
            int name = 0;
            int mail = 0;
            int pass = 0;
            int spaas = 0;


            if (nameBox.Text.Length >= 3)
            {
                name++;
            }

            string email = mailBox.Text;
            bool isValid = IsValidEmail(email);

            if (isValid)
            {
                mail++;
            }
            else
            {
                MessageBox.Show("Неправильно введена почта. Проверьте.");
            }

            if (passBox.Text.Length > 6)
            {
                pass++;
            }
            else
            {
                MessageBox.Show("Пароль слишком короткий");
            }

            if (spassBox.Text == spassBox.Text)
            {
                spaas++;
            }

            if (name == 1 & mail == 1 & pass == 1 & spaas == 1)
            {
                Window2 pg = new Window2();
                pg.Show();
                this.Close();
            }

        }
    }
}
